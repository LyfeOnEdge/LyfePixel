# LyfePixel
aka LIMP
- Lyfes
- Insanely 
- Multipurpose
- Picture-thingy

## A basic pixel art / pixel gif maker written in Tk / PIL / Python

ACNH QR code exporting is a main future goal.

![LyfePixel](assets/LyfePixel.jpg)
![Smile](assets/test.gif)